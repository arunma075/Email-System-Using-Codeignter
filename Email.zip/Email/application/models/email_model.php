<?php
class Email_model extends CI_model{

    function __construct() {
        // Call the Model constructor
        parent::__construct();
        $this->load->database();
	}

public function register_user($data){


$this->db->insert('emailreg', $data);

}

public function message($data){
    
    $this->db->insert('messages',$data);
    }
    
public  function send($email){
  $this->db->select("id,toaddr,subject,message");
  $this->db->from('messages');
  $this->db->where('fromaddr', $email);
  $query = $this->db->get();
  return $query->result();
 }
 
 function inbox($email){
  $this->db->select("id,fromaddr,subject,message");
  $this->db->from('messages');
  $this->db->where('toaddr', $email);
  $query = $this->db->get();
  return $query->result();
 }
function send_delete($id) {
        $this->db->where('id', $id);
        $query = $this->db->delete('message');
    
}
function inbox_delete($id) {
        $this->db->where('id', $id);
        $query = $this->db->delete('message');
    
}
	

public function login_user($uname,$paswrd){

  $this->db->select('*');
  $this->db->from('emailreg');
  $this->db->where('uname',$uname);
  $this->db->where('paswrd',$paswrd);

  if($query=$this->db->get())
  {
      return $query->row_array();
  }
  else{
    return false;
  }


}
public function email_check($email){

  $this->db->select('*');
  $this->db->from('emailreg');
  $this->db->where('email',$email);
  $query=$this->db->get();

  if($query->num_rows()>0){
    return false;
  }else{
    return true;
  }

}
}
?>





