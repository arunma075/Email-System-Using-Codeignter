<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
		<link rel="stylesheet" href="css/main.css" />



  <style>
body,h1 {font-family: "Raleway", sans-serif}
body, html {height: 100%}
</style>
</head>
<body background="http://localhost/arun/codearun/code/img/forestbridge.jpg" >
<nav class="navbar navbar-inverse">
  <ul class="nav navbar-nav">
    <li>  
            <li><a href="<?php echo site_url(); ?>/email/home" >Home</a></li>
            <li><a href="myModal1"  data-toggle="modal" data-target="#myModal1"></span>Compose</a></li>
            <li><a href="<?php echo site_url(); ?>/email/inbox" >Inbox</a></li>
            <li><a href="<?php echo site_url(); ?>/email/outbox" >Outbox</a></li>
            <li><a href="<?php echo site_url(); ?>/email/myprofile">My Profile</a></li>
            <li><a href="<?php echo site_url(); ?>/email/user_logout" >Log Out</a></li>
  </ul>
</nav>
 <div class="w3-display-middle  w3-text-white">
    <h1 class="w3-jumbo w3-animate-top w3-center">Tell!!!</h1>
    <hr class="w3-border-grey" style="margin:auto;width:40%">
    <p class="w3-large w3-center">Tell jokes, chat with people, and make stuff.
  </div>
  <div class="w3-display-bottomleft w3-padding-large">
    Powered by <a href="https://www.w3schools.com/w3css/default.asp" target="_blank">w3.css</a>
  </div>
        <form role="form" method="post" enctype="multipart/form-data" action="<?php echo site_url('email/compose'); ?>">
            
            <div class="modal fade" id="myModal1">
	<div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
              <label>To:</label>
    		<input class="form-control"  input type="email"name="toaddr">
  		  </div>
            <div class="form-group">
              <label>Subject:</label>
    		<input class="form-control" input type="text"name="subject" >
                  <td>   <span id="email-availability-status"></span> </td>
            </div>
		  <div class="form-group">
		  	<label>Message:</label>
                        <input class="form-control" textarea rows="4" cols="50" name="message">
		  </div>
        </div>
        <div class="modal-footer">
          <a href="#" data-dismiss="modal" class="btn">Close</a>
 	<button class="btn btn-primary" name="submit" type="submit">Compose</button>
        </div>
      </div>
    </div>
</div>
             </form>
    
    
    
      <script>
function checkAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "check_availability.php",
data:'email='+$("#email").val(),
type: "POST",
success:function(data){
$("#email-availability-status").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
</script>

</body>
</html>


