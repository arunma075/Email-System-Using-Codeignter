<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-inverse">
  <ul class="nav navbar-nav">
              <li><a href="<?php echo site_url(); ?>/email/home" >Home</a></li>
    <li><a href="<?php echo site_url(); ?>/email/create_message_view" >Create Message</a></li>
            <li><a href="<?php echo site_url(); ?>/email/inbox" >Inbox</a></li>
            <li><a href="<?php echo site_url(); ?>/email/outbox" >Outbox</a></li>
            <li><a href="<?php echo site_url(); ?>/email/myprofile">My Profile</a></li>
            <li><a href="<?php echo site_url(); ?>/email/user_logout" >Log Out</a></li>
  </ul>
</nav>
    
   <div class="w3-container">
  
  <table class="w3-table w3-striped">
    <tr>
    <tr>
    <th>To Address</th> 
    <th>Subject</th>
    <th>Message</th>
  
    

</tr>

    <?php
    foreach ($query as $row) {

?>


<tr>
<td><?php  echo $row->toaddr; ?></td>
<td><?php  echo $row->subject; ?></td>
<td><?php echo $row->message; ?></td>




<td>
<a href="<?php echo site_url('email/send_delete/'.$row->id);?>">Delete</a>
</td>

</tr>
<?php
    }
    ?>

</table>
    </body>
</html>